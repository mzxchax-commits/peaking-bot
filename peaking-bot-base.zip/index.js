import { Client, GatewayIntentBits, Events } from "discord.js";

const token = process.env.DISCORD_TOKEN;
const clientId = process.env.CLIENT_ID;

if (!token) {
  console.error("❌ Falta la variable DISCORD_TOKEN.");
  process.exit(1);
}

if (!clientId) {
  console.error("❌ Falta la variable CLIENT_ID.");
  process.exit(1);
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildInvites,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

client.once(Events.ClientReady, (readyClient) => {
  console.log(`✅ Peaking conectado como ${readyClient.user.tag}`);
  console.log(`🆔 Client ID: ${clientId}`);
});

client.on(Events.Error, (error) => {
  console.error("Discord client error:", error);
});

client.login(token);
